<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

/// ... file routes lainnya ...


$routes->get('/', 'Cv::index');
// ... file routes lainnya ...
